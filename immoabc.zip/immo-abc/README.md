# Immo-ABC – portables Drop-In-Paket

624 erklärte Fachbegriffe, statische A-Z-Übersicht + eine Detailseite pro Begriff.
Stack: Astro + TypeScript, eine NPM-Abhängigkeit (`marked` für Markdown-Rendering).

## Ordnerstruktur

```
immo-abc/
├── data/immobilien-abc.json          # 624 Terms (begriff, untertitel, definition)
├── lib/glossar.ts                    # Loader, Slug-Helper, Gruppierung A–Z
└── pages/immobilien-abc/
    ├── index.astro                   # A–Z-Übersicht mit Letter-Filter
    └── [slug].astro                  # Detail-Seite pro Begriff
```

## Einbau in ein anderes Astro-Repo

1. **Dateien kopieren** (Pfade ans Ziel-Repo anpassen, der Standard ist):
   ```
   src/data/immobilien-abc.json
   src/lib/glossar.ts
   src/pages/service/immobilien-abc/index.astro
   src/pages/service/immobilien-abc/[slug].astro
   ```
   Wenn die URL nicht `/service/immobilien-abc/` sein soll, einfach
   den `pages/`-Pfad ändern – die Seiten enthalten nur drei interne
   Links (im Hero-Breadcrumb, in der Sidebar und in der Index-Liste),
   die ggf. auf den neuen Pfad gezogen werden müssen.

2. **NPM-Abhängigkeit installieren** (einmalig pro Repo):
   ```bash
   npm install marked
   ```

3. **Drei Komponenten-Imports auf das Ziel-Repo mappen.** Die Pages
   nutzen vier Importe aus dem ursprünglichen Tandel-Repo:

   | Import                                   | Aufgabe                          | Im neuen Repo durch ersetzen…
   |------------------------------------------|----------------------------------|--------------------------------------------
   | `../../layouts/Base.astro`               | Site-weites `<html>` + Header/Footer | Das Layout des Ziel-Repos
   | `../../components/Breadcrumbs.astro`     | Brotkrumen unter dem Hero        | Eigene Breadcrumbs oder einfach entfernen
   | `../../components/PageHero.astro`        | Hero-Block oben                  | Eigene Hero-Komponente / Inline-`<header>`
   | `../../components/ContactCta.astro`      | Kontakt-Box unter dem Inhalt     | Eigene CTA / entfernen
   | `../../data/company.json`                | Liefert `company.name` für `<title>` | Eigene `company.json` oder hardcoded

   Wenn das Ziel-Repo keine entsprechenden Komponenten hat: alle vier
   Imports rauswerfen und durch nacktes HTML ersetzen – die Logik
   (Filter, Routing, Markdown-Rendering, JSON-LD) hängt ausschließlich
   an `lib/glossar.ts` und `data/immobilien-abc.json`.

4. **CSS-Variablen.** Die Pages nutzen `var(--brand)`, `var(--ink)`,
   `var(--ink-soft)`, `var(--paper)`, `var(--bg-soft)`, `var(--line)`,
   `var(--label)`. Entweder im globalen CSS des Ziel-Repos definieren
   oder per Suchen-und-Ersetzen durch feste Hex-Werte überschreiben.

5. **Build & Test:**
   ```bash
   npm run dev
   # → http://localhost:4321/service/immobilien-abc/
   ```

## API der Lib (`lib/glossar.ts`)

```ts
import { GLOSSAR, termBySlug, gruppiertNachBuchstabe, nachbarn, LETTERS } from "./lib/glossar";

GLOSSAR              // GlossarTerm[]   – alle 624 Terms, alphabetisch
termBySlug("agio")   // GlossarTerm | undefined
gruppiertNachBuchstabe()
                     // [{ letter: "A", terms: [...] }, …]
nachbarn("agio", 8)  // bis zu 8 alphabetische Nachbarn (für Sidebar)
LETTERS              // ["A","B","C",…] – nur Buchstaben, zu denen es Terms gibt
```

## SEO

`[slug].astro` rendert pro Begriff JSON-LD vom Typ `DefinedTerm` mit
`inDefinedTermSet`-Verweis auf die Übersicht. Description ist auto-
matisch aus Untertitel + ersten 160 Zeichen der Definition gebaut.
Astro übernimmt das in den `<head>`, sobald `Astro.site` in
`astro.config.mjs` gesetzt ist.

## Datenstand

- Quelle der ursprünglichen Begriffsdefinitionen: msi-hessen.de
- 624 Einträge, Format: `{ begriff, untertitel?, definition (Markdown) }`
- Aktualisieren: einfach die JSON ersetzen, alles andere bleibt.
